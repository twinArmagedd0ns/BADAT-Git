USE Cid_Colino_Rodrigo_Memes;
GO

INSERT INTO Profesor VALUES(
12,N'Chindasvinto', N'Garc�a',N'chindasvinto@visi.tol',N'Toledo',50
);
GO

INSERT INTO Asignatura VALUES(

304,N'Memes en la Espa�a visigoda',12, 10,NULL

);

INSERT INTO Alumno VALUES(

	12,	N'Terry',N'Pratchet',N'footnote',N'@discworld@penguinrandomhouse.uk',66

);
GO

INSERT INTO Matr�cula VALUES(

	12,304,12,1,NULL

);


